# Labor-Tracker
Labor Tracker Application

docker-compose up

API Base Path:
localhost:8080/
