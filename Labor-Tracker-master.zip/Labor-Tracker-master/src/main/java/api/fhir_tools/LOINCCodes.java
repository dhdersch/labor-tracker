package api.fhir_tools;

public class LOINCCodes {
    public static final String BMI = "39156-5";
    public static final String HEIGHT = "8302-2";
    public static final String WEIGHT = "3141-9";
}
